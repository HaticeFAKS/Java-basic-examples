import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

        System.out.print("Please enter a number:");
        int number=scanner.nextInt();
        if(number==1 || number==0){
            System.out.println("This is not a perfect number!");
        }
        else{
            int sum=0;
            for(int i=1;i<number;i++) {
                if(number%i==0) sum+=i;

            }

            if(sum==number) {
                System.out.println("This is a perfect number!");
            }
            else{
                System.out.println("This is not a perfect number!");
            }

        }

    }
}