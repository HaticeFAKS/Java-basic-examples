import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

        System.out.print("Please enter the first number:");
        int number1=scanner.nextInt();
        System.out.print("Please enter the second number:");
        int number2=scanner.nextInt();

        if(number1==sum(number2) && number2==sum(number1)){
            System.out.print("This numbers are friendly numbers");
        }
        else{
            System.out.print("This numbers are not friendly numbers");
        }


    }

    static int sum(int number){
        int sum=0;

        for(int i=1;i<number;i++){
            if(number%i==0) sum+=i;
        }
        return sum;

    }
}