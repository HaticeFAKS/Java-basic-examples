public class Main {
    public static void main(String[] args) {
        Circle circle=new Circle();
        Square square=new Square();
        Rectangle rectangle=new Rectangle();


        circle.screen();
        circle.area();
        circle.perimeter();

        square.screen();
        square.area();
        square.perimeter();

        rectangle.screen();
        rectangle.area();
        rectangle.perimeter();


    }
}