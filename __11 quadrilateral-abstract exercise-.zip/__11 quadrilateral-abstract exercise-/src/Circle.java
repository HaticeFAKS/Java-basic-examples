public class Circle extends Shape{
    private final double pi=3.14;
    @Override
    public void area() {
        System.out.print("Please enter the radius of circle:");
        length1=scanner.nextDouble();
        System.out.println("The area is: "+length1*length1*pi);

    }

    @Override
            public void perimeter()
    {
        System.out.println("The perimeter is:"+2*pi*length1);
    }


}
