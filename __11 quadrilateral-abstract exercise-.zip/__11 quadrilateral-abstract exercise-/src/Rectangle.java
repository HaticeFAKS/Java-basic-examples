public class Rectangle extends Shape{
    public void area() {
        System.out.print("Please enter the first length of rectangle:");
        length1=scanner.nextDouble();
        System.out.print("Please enter the second length of rectangle:");
        length2=scanner.nextDouble();
        System.out.println("The area is:"+length1*length2);


    }

    @Override
    public void perimeter() {

        System.out.println("The perimeter is:"+2*(length1+length2));

    }
}
