public class Square extends Shape{
    @Override
    public  void area() {

        System.out.print("Please enter the length of square:");
        length1=scanner.nextDouble();
        System.out.println("The area is:"+length1*length1);


    }

    @Override
    public void perimeter() {

        System.out.println("The perimeter is:"+4*length1);
    }
}
