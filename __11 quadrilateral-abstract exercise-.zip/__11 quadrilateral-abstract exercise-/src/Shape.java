import java.util.Scanner;
public abstract class Shape {
    protected static   Scanner scanner=new Scanner(System.in);
    protected   double  length1;
    protected  double  length2;

    public abstract void area();
    public abstract void perimeter();

    public final void screen()
    {
        System.out.println("\n\nThis is a shape");
    }

}
