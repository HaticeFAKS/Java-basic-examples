import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

        System.out.print("Please enter a letter:");
        char letter=scanner.next().charAt(0);

        while(!Character.isLetter(letter)){
            System.out.print("This invalid value.Please enter a letter:");
           letter=scanner.next().charAt(0);
        }
        letter=Character.toLowerCase(letter);
        switch (letter){
            case 'a':
            case 'e':
            case 'o':
            case 'u':
            case 'i':
                System.out.println("This is a vowel letter");
                break;
            default:
                System.out.println("This is a consonant letter");

        }

    }
}